---
title: Ma deuxième année 
publishDate: 2020-03-02 00:00:00
img: /assets/stock-3.jpg
img_alt: Iridescent ripples of a bright blue and pink liquid
description: |
  Durant cette année, j'ai pu réalisé un premier grand projet de programmation d'une caisse automatisée en groupe, du recueil des besoins au résultat final, et j'ai également effectué un stage de 2 mois afin d'acquérir de l'expérience.
tags:
  - Grand projet 
  - Stage
---

## Deuxième Année



### Compétence 1 : Réaliser un développement d'application

En deuxième année, j'ai approfondi mes connaissances en développement d'application. <br><br> Un projet particulièrement marquant a été le développement d'une application en équipe durant le premier semestre. <br>Ce projet m'a permis de travailler avec des langages comme PHP, Javascript, HTML, CSS et SQL. J'ai appris à utiliser des frameworks et des bibliothèques pour améliorer l'efficacité et la qualité de mon code. <br><br>Nous avons également utilisé des outils pour dessiner des diagrammes UML et rédiger un cahier des charges. <br><br>Ce projet m'a permis de consolider mes bases en développement tout en apprenant de nouvelles compétences, comme la gestion de projet, la rédaction de user stories et la communication avec les clients.

#### Outils et technologies :

<u>Langages</u> : PHP, Javascript, HTML, CSS, SQL<br>
<u>Outils</u> : Frameworks, Bibliothèques, Diagrammes UML<br>
Compétences : Gestion de projet, Rédaction de cahier des charges, User stories

### Compétence 2 : Optimiser des applications informatiques

J'ai continué à améliorer mes compétences en optimisation des applications.<br> Durant mon stage, j'ai découvert les applications SPA (Single Page Application), qui permettent de rendre les interactions plus fluides en évitant de recharger la page à chaque action de l'utilisateur. <br><br>J'ai travaillé sur l'optimisation des performances d'un site web, en utilisant des techniques comme la minimisation des fichiers CSS et JavaScript, la mise en cache et le responsive design. <br><br>Ces techniques m'ont permis d'améliorer l'expérience utilisateur et de rendre les sites plus rapides et plus efficaces.

#### Outils et technologies :

<u>Framework</u> : VueJS<br>
<u>Concepts</u> : SPA, Responsiveness, Minimisation des fichiers, Mise en cache<br>
<u>Compétences</u> : Optimisation des performances, Expérience utilisateur

### Compétence 3 : Administrer des systèmes informatiques communicants

En deuxième année, j'ai approfondi mes connaissances en administration des systèmes informatiques. <br><br>J'ai travaillé avec des outils de virtualisation comme Marionnet pour simuler des réseaux locaux. J'ai appris à créer des représentations virtuelles de serveurs, de stockages et de réseaux, et à utiliser des commandes avancées pour administrer ces systèmes. J'ai également consolidé mes connaissances en réseau, en apprenant à configurer et gérer des serveurs, des routeurs et des switchs. <br><br>Ces compétences m'ont permis de mieux comprendre les infrastructures réseau et de gérer des systèmes complexes.

#### Outils et technologies :

<u>Logiciels</u> : Marionnet <br>
<u>Commandes</u> : useradd, groupadd<br>
<u>Concepts</u> : Virtualisation, Administration de serveurs, Gestion des réseaux

### Compétence 4 : Gérer des données de l’information

La gestion des données a continué à être un aspect important de ma formation en deuxième année. <br> J'ai travaillé sur des projets nécessitant la création et la gestion de bases de données complexes.<br><br> Durant mon stage, j'ai utilisé Firebase pour créer et gérer des bases de données pour le site web de l'entreprise. J'ai appris à utiliser des outils de gestion de bases de données en ligne et à écrire des requêtes SQL avancées pour manipuler et analyser les données. <br><br>Ces projets m'ont permis de comprendre l'importance de la gestion des données dans le développement d'applications et d'acquérir des compétences en analyse de données.

#### Outils et technologies :

<u>Base de données :</u> Firebase<br>
<u>Langage :</u> SQL<br>
<u>Compétences :</u> Création et gestion de bases de données, Analyse de données

### Compétence 5 : Conduire un projet

Mon stage en deuxième année m'a permis de conduire un projet de développement web en utilisant le framework VueJS. <br><br> J'ai  rédigé des user stories et utiliseé des méthodes agiles pour gérer le développement.<br> J'ai également appris à communiquer efficacement avec mon client pour résoudre les problèmes et assurer la qualité du produit final.

#### Outils et technologies :

<u>Framework :</u> VueJS<br>
<u>Langages :</u> HTML, CSS, Javascript<br>
<u>Compétences :</u> Gestion de projet, Méthodes agiles, Communication avec un client

### Compétence 6 : Travailler dans une équipe informatique

J'ai continué à développer mes compétences de travail en équipe durant ma deuxième année.<br><br> Durant la SAE qui nous a suivi tout au long de l'année, j'ai travaillé en étroite collaboration avec mon équipe et les clients. J'ai utilisé des outils comme Github pour gérer le code, et des plateformes de communication comme Whatsapp et Discord pour rester en contact et résoudre les problèmes rapidement. Ces expériences m'ont aidé à améliorer ma communication et ma capacité à travailler en équipe.

#### Outils et technologies :

<u>Plateforme :</u> Github<br>
<u>Communication :</u> Whatsapp, Discord<br>
<u>Compétences :</u> Communication, esprit d'équipe