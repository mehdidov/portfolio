---
title: Ma première année 
publishDate: 2020-03-02 00:00:00
img: /assets/stock-3.jpg
img_alt: Iridescent ripples of a bright blue and pink liquid
description: |
  Durant ma première année de formation, j'ai pu revoir les bases de l'informatique et de la programmation que j'avais apprises au lycée en NSI. J'ai également acquis de nouvelles connaissances et renforcé mes compétences.
tags:
  - Découverte
---

## Introduction

>  La logique de mon	parcours,	les raisons	de	
mon choix	d’orientation,	mes ambitions	professionnelles ainsi que ma poursuite	d’étude.

L’informatique est un domaine qui m’a toujours fasciné, que ce soit par l’utilisation d’ordinateurs, de téléphones ou de tablettes. Dès le lycée, j’ai commencé à m'intéresser à ce domaine pour comprendre comment ces technologies fonctionnent et quels sont les différents aspects de l'informatique. Cette curiosité m'a conduit à choisir l'informatique comme domaine d'étude et de future carrière.<br><br> Actuellement en deuxième année de BUT, je suis convaincu d'avoir fait le bon choix. Les formations et les projets que j'ai réalisés ont renforcé mon envie de continuer dans cette voie, et m'ont permis d'acquérir de nombreuses connaissances et compétences. <br><br>Mon ambition professionnelle est de devenir un expert en développement d’applications, avec une spécialisation dans les technologies web et mobiles. Je prévois de poursuivre mes études pour approfondir mes connaissances et me perfectionner dans ce domaine.

### Compétence 1 : Réaliser un développement d'application

Lors de ma première année, j'ai acquis de solides bases en développement d'application grâce à plusieurs projets pratiques. L'un des projets marquants a été la réalisation d'une calculatrice en Java. Ce projet m'a permis de me familiariser avec les concepts fondamentaux de la programmation orientée objet, les structures de contrôle et les méthodes de gestion des erreurs. <br><br> J'ai également travaillé sur un algorithme de chiffrement de César en Python, ce qui m'a donné l'occasion de renforcer mes compétences en logique algorithmique et en manipulation de chaînes de caractères. <br><br> Python a été un langage central dans notre formation, et j'ai pu approfondir mes connaissances grâce à de nombreux exercices et projets pratiques. Ces expériences m'ont permis de comprendre l'importance de la rigueur et de la précision dans le développement logiciel.

#### Outils et technologies :

<u>Langages</u> : Java, Python
Projets : Calculatrice en Java, Algorithme de chiffrement de César en Python
Concepts : Programmation orientée objet, Algorithmes

### Compétence 2 : Optimiser des applications informatiques

J'ai travaillé sur des algorithmes pour optimiser les applications, ce qui m'a permis de comprendre l'importance de l'efficacité et des performances dans le développement logiciel. Par exemple, j'ai choisi de travailler sur l'algorithme de Dijkstra pour un projet de première année.<br><br> Cet algorithme, utilisé pour trouver le chemin le plus court dans un graphe, m'a permis de mieux comprendre les concepts de graphes, de chemins et de coûts. J'ai non seulement implémenté cet algorithme en Python, mais aussi étudié d'autres algorithmes similaires pour comparer leur efficacité. <br><br>Ce projet m'a également permis d'explorer des outils d'analyse de performance et d'optimisation de code, ce qui est crucial pour développer des applications efficaces.

#### Outils et technologies :

<u>Langage</u> : Python <br>
<u>Projet</u> : Algorithme de Dijkstra <br>
<u>Concepts</u> : Optimisation des algorithmes, Analyse de performance


### Compétence 3 : Administrer des systèmes informatiques communicants
 
 J'ai découvert le Raspberry Pi et appris à l'utiliser, ce qui m'a permis de me familiariser avec les réseaux et les commandes sur un terminal Linux.<br/> J'ai appris à configurer et administrer un système Linux, en commençant par les bases comme l'installation du système d'exploitation et l'exécution des commandes de base.<br/><br/> J'ai ensuite approfondi mes connaissances en réseau, en apprenant à configurer des adresses IP, à utiliser des outils de diagnostic réseau et à gérer des services réseau. <br/><br/>Ces compétences m'ont été très utiles pour comprendre comment les systèmes informatiques communiquent entre eux et pour résoudre des problèmes de connectivité.


#### Outils et technologies :

<u>Matériel</u> : Raspberry Pi <br/>
<u>Logiciels</u> : Terminal Linux <br/>
<u>Compétences</u> : Configuration d'adresses IP, Commandes Linux, Gestion des services réseau

### Compétence 4 : Gérer des données de l’information

La gestion des données a été un aspect important de ma première année. J'ai participé à un projet où nous devions créer une base de données pour l'IUT.<br/> Ce projet m'a permis de comprendre les principes de conception de bases de données, l'analyse des besoins des utilisateurs et la structuration des données. <br/> J'ai utilisé PostgreSQL pour créer, gérer et interroger la base de données. Un autre projet consistait à extraire des données d'un fichier sur le Titanic et à les importer dans une base de données PostgreSQL.<br/><br/> Ces projets m'ont aidé à maîtriser le langage SQL et à comprendre l'importance de la qualité des données et de leur organisation pour des applications informatiques efficaces.

#### Outils et technologies :

<u>Base de données</u> : PostgreSQL <br/>
<u>Langage</u> : SQL <br/>
<u>Projets</u> : Base de données pour l'IUT, extraction et importation de données du Titanic

### Compétence 5 : Conduire un projet

Un projet marquant de ma première année a été la création d'un site web pour un couple de mariés. <br/> Ce projet m'a permis de développer mes compétences en gestion de projet, de la collecte des besoins à la livraison du produit final. <br/><br/> J'ai appris à communiquer avec les clients pour comprendre leurs attentes et à traduire ces attentes en spécifications techniques. J'ai utilisé HTML et CSS pour créer le site, en m'assurant qu'il soit esthétique et fonctionnel. <br/><br/>J'ai également participé à un projet pour présenter un concours d’éloquence, ce qui m'a permis de consolider mes compétences en HTML et CSS et d'améliorer ma capacité à travailler sur des projets collaboratifs.

#### Outils et technologies :

<u>Langages</u> : HTML, CSS <br/>
<u>Projets</u> : Site web pour un mariage, Site pour un concours d’éloquence<br/>
<u>Compétences</u> : Gestion de projet, Communication avec les clients

### Compétence 6 : Travailler dans une équipe informatique

J'ai participé à plusieurs projets en équipe, ce qui m'a permis de développer mes compétences en collaboration et en organisation. <br/><br/>Par exemple, lors de la SAE "Organisation d’un travail d’équipe", nous avons dû répartir les tâches et coordonner nos efforts pour réaliser une mission confiée par une organisation œuvrant dans le domaine du numérique. <br/><br/>J'ai également travaillé sur la SAE "Découverte de l’environnement économique et écologique", où nous devions présenter le positionnement économique ou écologique d'une entreprise. <br/><br/>Ces projets m'ont aidé à améliorer ma communication, à apprendre à gérer les conflits et à comprendre l'importance de la collaboration pour atteindre des objectifs communs.

#### Projets en équipe :

SAE "Organisation d’un travail d’équipe"<br/>
SAE "Découverte de l’environnement économique et écologique"<br/>
<u>Compétences :</u> Collaboration, Communication, Gestion des conflits


