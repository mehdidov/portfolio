package fr.einfolearning.tp2.metiers.exceptions;

public class EmacsKillRingOverflowException extends Throwable {
    public EmacsKillRingOverflowException(String message) {
        super(message);
    }
}
